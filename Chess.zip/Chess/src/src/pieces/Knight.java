package pieces;

import java.util.ArrayList;

import chess.Cell;

/**
 *
 * @author ivan
 */
/**

/**
 * Esta es la clase Knight heredada de la clase abstracta Piece
 *
 *  
 *
 */
public class Knight extends Piece{
	
	//Constructor
	public Knight(String i,String p,int c)
	{
		setId(i);
		setPath(p);
		setColor(c);
	}
	
	
	// Función de movimiento anulada
	//Hay un máximo de 8 movimientos posibles para un caballo en cualquier momento.
	//El caballero se mueve solo 2(1/2) pasos
        /**
         * 
         * @param state Es la matriz que recibe la funcion que debe de ser el tablero donde estan las fichas
         * @param x es la primera posicion de la donde se encuentra la ficha en la matriz
         * @param y es la segunda posicion de la donde se encuentra la ficha en la matriz
         * @return  Devuelve una lista de todos los destinos posibles del caballo
          @version 1.0
          */
	public ArrayList<Cell> move(Cell state[][],int x,int y)
	{
		possiblemoves.clear();
		int posx[]={x+1,x+1,x+2,x+2,x-1,x-1,x-2,x-2};
		int posy[]={y-2,y+2,y-1,y+1,y-2,y+2,y-1,y+1};
		for(int i=0;i<8;i++)
			if((posx[i]>=0&&posx[i]<8&&posy[i]>=0&&posy[i]<8))
				if((state[posx[i]][posy[i]].getpiece()==null||state[posx[i]][posy[i]].getpiece().getcolor()!=this.getcolor()))
				{
					possiblemoves.add(state[posx[i]][posy[i]]);
				}
		return possiblemoves;
	}
}