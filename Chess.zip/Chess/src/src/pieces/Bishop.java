package pieces;

import java.util.ArrayList;

import chess.Cell;


/**
 *
 * @author ivan
 */
/**
 * Esta es la Clase Bishop.
 * La función de movimiento define las reglas básicas para el movimiento del alfil en un tablero de ajedrez
 * 
 *
 */
public class Bishop extends Piece{
	
	//Constructor
	public Bishop(String i,String p,int c)
	{
		setId(i);
		setPath(p);
		setColor(c);
	}
	
	// función de movimiento definida. Devuelve una lista de todos los destinos posibles de un Obispo
	//Se ha implementado el principio básico del movimiento de obispos en el tablero de ajedrez
        /**
         * 
         * @param state Es la matriz que recibe la funcion que debe de ser el tablero donde estan las fichas
         * @param x es la primera posicion de la donde se encuentra la ficha en la matriz
         * @param y es la segunda posicion de la donde se encuentra la ficha en la matriz
         * @return  Devuelve una lista de todos los destinos posibles del Obispo
          @version 1.0
          */
	public ArrayList<Cell> move(Cell state[][],int x,int y)
	{
		//El obispo puede moverse en diagonal en las 4 direcciones (NW,NE,SW,SE)
		//Esta función define esa lógica
		possiblemoves.clear();
		int tempx=x+1,tempy=y-1;
		while(tempx<8&&tempy>=0)
		{
			if(state[tempx][tempy].getpiece()==null)
			{
				possiblemoves.add(state[tempx][tempy]);
			}
			else if(state[tempx][tempy].getpiece().getcolor()==this.getcolor())
				break;
			else
			{
				possiblemoves.add(state[tempx][tempy]);
				break;
			}
			tempx++;
			tempy--;
		}
		tempx=x-1;tempy=y+1;
		while(tempx>=0&&tempy<8)
		{
			if(state[tempx][tempy].getpiece()==null)
				possiblemoves.add(state[tempx][tempy]);
			else if(state[tempx][tempy].getpiece().getcolor()==this.getcolor())
				break;
			else
			{
				possiblemoves.add(state[tempx][tempy]);
				break;
			}
			tempx--;
			tempy++;
		}
		tempx=x-1;tempy=y-1;
		while(tempx>=0&&tempy>=0)
		{
			if(state[tempx][tempy].getpiece()==null)
				possiblemoves.add(state[tempx][tempy]);
			else if(state[tempx][tempy].getpiece().getcolor()==this.getcolor())
				break;
			else
			{
				possiblemoves.add(state[tempx][tempy]);
				break;
			}
			tempx--;
			tempy--;
		}
		tempx=x+1;tempy=y+1;
		while(tempx<8&&tempy<8)
		{
			if(state[tempx][tempy].getpiece()==null)
				possiblemoves.add(state[tempx][tempy]);
			else if(state[tempx][tempy].getpiece().getcolor()==this.getcolor())
				break;
			else
			{
				possiblemoves.add(state[tempx][tempy]);
				break;
			}
			tempx++;
			tempy++;
		}
		return possiblemoves;
	}
}